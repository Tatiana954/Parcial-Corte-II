const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://mwomnkpevluqdftukhnq.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im13b21ua3Bldmx1cWRmdHVraG5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU0MjM5MTcsImV4cCI6MjA2MDk5OTkxN30.xpDJVcSojiTAqlR8a4XWa1bDW6E7sWloNM6hyU5kLyc';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

module.exports = supabase;
