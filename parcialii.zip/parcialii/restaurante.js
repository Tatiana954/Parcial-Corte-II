require('dotenv').config();
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const db = require('./db');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.send('API funcionando ✅');
});


app.get('/restaurante', (req, res) => {
  db.query('SELECT * FROM restaurante', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});


app.get('/restaurante', (req, res) => {
  db.query('SELECT * FROM restaurante', (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});


app.post('/restaurante', (req, res) => {
  const { nombre, ciudad, direccion, fecha_apertura } = req.body;
  db.query(
    'INSERT INTO restaurante (nombre, ciudad, direccion, fecha_apertura) VALUES (?, ?, ?, ?)',
    [nombre, ciudad, direccion, fecha_apertura],
    (err, result) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Restaurante agregada', id: result.insertId });
    }
  );
});



const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
