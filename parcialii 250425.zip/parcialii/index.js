const express = require('express');
require('dotenv').config();
const app = express();
const port = process.env.PORT || 3000;
const queryRoutes = require('./query');

app.use(express.json());


app.use('/restaurante', require('./routes/restaurante'));
app.use('/empleado', require('./routes/empleado'));
app.use('/producto', require('./routes/producto'));
app.use('/pedido', require('./routes/pedido'));
app.use('/detalle', require('./routes/detalle_pedido'));
app.use('/consultas', queryRoutes);

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
