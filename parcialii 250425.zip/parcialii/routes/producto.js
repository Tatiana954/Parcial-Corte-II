const express = require('express');
const router = express.Router();
const supabase = require('../db/supabaseClient');

// Obtener todos los productos
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('producto').select('*');
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Obtener un producto por ID
router.get('/:id', async (req, res) => {
  const { data, error } = await supabase.from('producto').select('*').eq('id_prod', req.params.id).single();
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Crear producto
router.post('/', async (req, res) => {
  const { id_prod, nombre, precio } = req.body;
  const { data, error } = await supabase.from('producto').insert([{ id_prod, nombre, precio }]);
  if (error) return res.status(500).json(error);
  res.status(201).json(data);
});

// Actualizar producto
router.put('/:id', async (req, res) => {
  const { nombre, precio } = req.body;
  const { data, error } = await supabase.from('producto').update({ nombre, precio }).eq('id_prod', req.params.id);
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Eliminar producto
router.delete('/:id', async (req, res) => {
  const { error } = await supabase.from('producto').delete().eq('id_prod', req.params.id);
  if (error) return res.status(500).json(error);
  res.sendStatus(204);
});

module.exports = router;
