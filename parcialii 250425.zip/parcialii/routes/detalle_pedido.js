const express = require('express');
const router = express.Router();
const supabase = require('../db/supabaseClient');

// Obtener todos los detalles
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('detalle_pedido').select('*');
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Obtener un detalle por ID
router.get('/:id', async (req, res) => {
  const { data, error } = await supabase.from('detalle_pedido').select('*').eq('id_detalle', req.params.id).single();
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Crear detalle
router.post('/', async (req, res) => {
  const { id_detalle, id_pedido, id_prod, cantidad, subtotal } = req.body;
  const { data, error } = await supabase.from('detalle_pedido').insert([{ id_detalle, id_pedido, id_prod, cantidad, subtotal }]);
  if (error) return res.status(500).json(error);
  res.status(201).json(data);
});

// Actualizar detalle
router.put('/:id', async (req, res) => {
  const { id_pedido, id_prod, cantidad, subtotal } = req.body;
  const { data, error } = await supabase.from('detalle_pedido').update({ id_pedido, id_prod, cantidad, subtotal }).eq('id_detalle', req.params.id);
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Eliminar detalle
router.delete('/:id', async (req, res) => {
  const { error } = await supabase.from('detalle_pedido').delete().eq('id_detalle', req.params.id);
  if (error) return res.status(500).json(error);
  res.sendStatus(204);
});

module.exports = router;
