const express = require('express');
const router = express.Router();
const supabase = require('../db/supabaseClient');

// Obtener todos los pedidos
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('pedido').select('*');
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Obtener un pedido por ID
router.get('/:id', async (req, res) => {
  const { data, error } = await supabase.from('pedido').select('*').eq('id_pedido', req.params.id).single();
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Crear pedido
router.post('/', async (req, res) => {
  const { id_pedido, fecha, id_rest, total } = req.body;
  const { data, error } = await supabase.from('pedido').insert([{ id_pedido, fecha, id_rest, total }]);
  if (error) return res.status(500).json(error);
  res.status(201).json(data);
});

// Actualizar pedido
router.put('/:id', async (req, res) => {
  const { fecha, id_rest, total } = req.body;
  const { data, error } = await supabase.from('pedido').update({ fecha, id_rest, total }).eq('id_pedido', req.params.id);
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Eliminar pedido
router.delete('/:id', async (req, res) => {
  const { error } = await supabase.from('pedido').delete().eq('id_pedido', req.params.id);
  if (error) return res.status(500).json(error);
  res.sendStatus(204);
});

module.exports = router;
