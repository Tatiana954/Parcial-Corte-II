const express = require('express');
const router = express.Router();
const supabase = require('../db/supabaseClient');

// Obtener todos los restaurantes
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('restaurante').select('*');
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Obtener uno por id
router.get('/:id', async (req, res) => {
  const { data, error } = await supabase
    .from('restaurante')
    .select('*')
    .eq('id_rest', req.params.id)
    .single();
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Crear un nuevo restaurante
router.post('/', async (req, res) => {
  const { id_rest, nombre, ciudad, direccion, fecha_apertura } = req.body;
  const { data, error } = await supabase.from('restaurante').insert([
    { id_rest, nombre, ciudad, direccion, fecha_apertura },
  ]);
  if (error) return res.status(500).json(error);
  res.status(201).json(data);
});

// Actualizar restaurante
router.put('/:id', async (req, res) => {
  const { nombre, ciudad, direccion, fecha_apertura } = req.body;
  const { data, error } = await supabase
    .from('restaurante')
    .update({ nombre, ciudad, direccion, fecha_apertura })
    .eq('id_rest', req.params.id);
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Eliminar restaurante
router.delete('/:id', async (req, res) => {
  const { error } = await supabase
    .from('restaurante')
    .delete()
    .eq('id_rest', req.params.id);
  if (error) return res.status(500).json(error);
  res.sendStatus(204);
});

module.exports = router;
