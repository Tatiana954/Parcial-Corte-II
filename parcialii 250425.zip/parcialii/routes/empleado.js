const express = require('express');
const router = express.Router();
const supabase = require('../db/supabaseClient');

// Obtener empleados
router.get('/', async (req, res) => {
  const { data, error } = await supabase.from('empleado').select('*');
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Obtener un empleado por ID
router.get('/:id', async (req, res) => {
  const { data, error } = await supabase.from('empleado').select('*').eq('id_empleado', req.params.id).single();
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Crear empleado
router.post('/', async (req, res) => {
  const { id_empleado, nombre, rol, id_rest } = req.body;
  const { data, error } = await supabase.from('empleado').insert([{ id_empleado, nombre, rol, id_rest }]);
  if (error) return res.status(500).json(error);
  res.status(201).json(data);
});

// Actualizar empleado
router.put('/:id', async (req, res) => {
  const { nombre, rol, id_rest } = req.body;
  const { data, error } = await supabase.from('empleado').update({ nombre, rol, id_rest }).eq('id_empleado', req.params.id);
  if (error) return res.status(500).json(error);
  res.json(data);
});

// Eliminar empleado
router.delete('/:id', async (req, res) => {
  const { error } = await supabase.from('empleado').delete().eq('id_empleado', req.params.id);
  if (error) return res.status(500).json(error);
  res.sendStatus(204);
});

module.exports = router;
