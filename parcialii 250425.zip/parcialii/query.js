const express = require('express');
const router = express.Router();
const supabase = require('./db/supabaseClient');



module.exports = router;
